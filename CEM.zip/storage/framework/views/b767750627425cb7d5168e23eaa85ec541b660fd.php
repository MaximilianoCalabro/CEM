<?php $__env->startSection('contenido'); ?>
<div class="row">
	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
		<h3>- Noticias - <a href="/noticias/inicio/create"><button class="btn btn-success">Nuevo</button></a></h3>
	</div>
</div>

<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<div class="table-responsive">
			<table class="table table-striped table-bordered table-condensed table-hover">
				<thead>
					<th>Título</th>
					<th>Subtítulo</th>
					<th>Fecha</th>
					<th>Imágen</th>
					<th>Noticia</th>
					<th>Imágenes Slider</th>
				</thead>
               <?php $__currentLoopData = $noticias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($cat->titulo); ?></td>
					<td><?php echo e($cat->subtitulo); ?></td>
					<td><?php echo e($cat->fecha); ?></td>
					<td><img src="<?php echo e(asset('img/'.$cat->imagen)); ?>" height="150px" width="150px"></td>
					<td><?php echo e($cat->noticia); ?></td>
					<?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($s->id_noticias == $cat->id_noticias): ?>
						<td style="border: 1px solid black;">
							<img src="<?php echo e(asset('img/slider/'.$s->imagen_slider)); ?>" height="100px" width="100px">
							<?php echo e(Form::Open(array('action'=>array('SliderController@destroy',$s->id_slider),'method'=>'delete'))); ?>

							<a href="" data-target="#modalslider-delete-<?php echo e($s->id_slider); ?>" data-toggle="modalslider"><button type="submit" class="btn btn-danger" style="float: right;">X</button></a>
							<?php echo e(Form::Close()); ?>

						</td>
						<?php endif; ?>
						<?php echo $__env->make('noticias.inicio.modalslider', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<td>
						<a href="<?php echo e(URL::action('NoticiasController@edit',$cat->id_noticias)); ?>"><button class="btn btn-info">Editar</button></a>
                        <a href="" data-target="#modal-delete-<?php echo e($cat->id_noticias); ?>" data-toggle="modal"><button class="btn btn-danger">Eliminar</button></a>
					</td>
				</tr>
				
				<?php echo $__env->make('noticias.inicio.modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</table>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>